import { useState, useEffect, useCallback, useRef } from "react";
import {
  Shield, Activity, AlertTriangle, CheckCircle2, XCircle, Zap,
  Send, Clock, SkipForward, RotateCcw, Terminal, Sparkles,
  Globe, Server, Mail, TrendingUp, TrendingDown, Info, ChevronRight
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";
import { motion, AnimatePresence } from "framer-motion";

// ─── API Placeholders ─────────────────────────────────────────────
// async function syncWithMailerLite(apiKey: string) {
//   const res = await fetch("https://connect.mailerlite.com/api/subscribers", {
//     headers: { Authorization: `Bearer ${apiKey}` }
//   });
//   return res.json();
// }
// async function callSambaNovaAPI(emailContent: string) {
//   const res = await fetch("https://api.sambanova.ai/v1/chat/completions", {
//     method: "POST",
//     headers: { Authorization: "Bearer SAMBANOVA_API_KEY" },
//     body: JSON.stringify({ prompt: `Rewrite this to reduce spam score: ${emailContent}` })
//   });
//   return res.json();
// }

// ─── Types ─────────────────────────────────────────────────────────
interface QueueItem {
  id: number;
  email: string;
  name: string;
  segment: "Friendlies" | "Cold";
  status: "Pending" | "Sent" | "Throttled" | "Spam Trap";
  sentFrom: string;
  engagement: number;
}

interface LogEntry {
  id: number;
  time: string;
  type: "info" | "alert" | "action" | "success";
  message: string;
}

interface ChartPoint {
  time: string;
  bounces: number;
  spam: number;
}

// ─── Mock Data ─────────────────────────────────────────────────────
const MOCK_SUBSCRIBERS: Omit<QueueItem, "id" | "status" | "sentFrom">[] = [
  { email: "sarah.chen@techcorp.io", name: "Sarah Chen", segment: "Friendlies", engagement: 95 },
  { email: "james.wu@startup.co", name: "James Wu", segment: "Friendlies", engagement: 88 },
  { email: "elena.petrov@bigco.com", name: "Elena Petrov", segment: "Friendlies", engagement: 82 },
  { email: "dev.team@acme.org", name: "Dev Team", segment: "Friendlies", engagement: 79 },
  { email: "m.johnson@retailhq.com", name: "M. Johnson", segment: "Friendlies", engagement: 76 },
  { email: "priya.sharma@cloud9.dev", name: "Priya Sharma", segment: "Cold", engagement: 42 },
  { email: "alex.torres@newlead.io", name: "Alex Torres", segment: "Cold", engagement: 35 },
  { email: "info@randomsite.net", name: "Info Desk", segment: "Cold", engagement: 22 },
  { email: "contact@unknown-biz.co", name: "Unknown Biz", segment: "Cold", engagement: 15 },
  { email: "newsletter@scraped-list.com", name: "Newsletter", segment: "Cold", engagement: 8 },
  { email: "lisa.park@innovate.tech", name: "Lisa Park", segment: "Friendlies", engagement: 91 },
  { email: "mark.reed@enterprise.com", name: "Mark Reed", segment: "Cold", engagement: 28 },
  { email: "anna.kowalski@design.studio", name: "Anna Kowalski", segment: "Friendlies", engagement: 85 },
  { email: "no-reply@bulk-sender.xyz", name: "Bulk Sender", segment: "Cold", engagement: 5 },
  { email: "t.nguyen@saas.io", name: "T. Nguyen", segment: "Friendlies", engagement: 73 },
];

const SPAMMY_EMAIL = {
  subject: "🔥 BUY NOW!!! FREE $$$ LIMITED TIME ONLY!!!",
  body: "CONGRATULATIONS!!! You've been SELECTED for an EXCLUSIVE deal! BUY NOW and get FREE MONEY!!! Click HERE for $$$!!! ACT NOW before this ONCE-IN-A-LIFETIME offer EXPIRES!!! 100% FREE NO RISK!!!",
};

const CLEAN_EMAIL = {
  subject: "Your weekly product update from Acme",
  body: "Hi there — here's what's new this week at Acme. We've shipped three improvements to our dashboard that we think you'll love. Check out the details in our latest blog post. As always, reply to this email if you have any questions.",
};

function generateInitialChart(): ChartPoint[] {
  return Array.from({ length: 24 }, (_, i) => ({
    time: `${String(i).padStart(2, "0")}:00`,
    bounces: Math.random() * 0.3 + 0.1,
    spam: Math.random() * 0.08 + 0.01,
  }));
}

function now() {
  return new Date().toLocaleTimeString("en-US", { hour12: false });
}

// ─── Sub-components ────────────────────────────────────────────────

function ScoreGauge({ score }: { score: number }) {
  const circumference = 2 * Math.PI * 70;
  const progress = (score / 100) * circumference;
  const color = score > 80 ? "hsl(160,84%,39%)" : score > 50 ? "hsl(38,92%,50%)" : "hsl(0,72%,51%)";
  const glowClass = score > 80 ? "score-ring" : "";

  return (
    <div className="relative flex items-center justify-center">
      <svg width="180" height="180" className={glowClass}>
        <circle cx="90" cy="90" r="70" fill="none" stroke="hsl(222,30%,16%)" strokeWidth="8" />
        <circle
          cx="90" cy="90" r="70" fill="none" stroke={color} strokeWidth="8"
          strokeDasharray={circumference} strokeDashoffset={circumference - progress}
          strokeLinecap="round"
          transform="rotate(-90 90 90)"
          style={{ transition: "stroke-dashoffset 1s ease, stroke 0.5s ease" }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-4xl font-bold font-mono" style={{ color, transition: "color 0.5s ease" }}>
          {score}
        </span>
        <span className="text-xs text-muted-foreground mt-1">Deliverability</span>
      </div>
    </div>
  );
}

function DomainCard({ domain, spf, dkim, dmarc, dmarcStrict, burned }: {
  domain: string; spf: boolean; dkim: boolean; dmarc: boolean; dmarcStrict?: boolean; burned?: boolean;
}) {
  return (
    <div className={`gradient-card rounded-xl p-4 ${burned ? "glow-rose border-danger/30" : "glow-cyan"}`}>
      <div className="flex items-center gap-2 mb-3">
        <Globe className={`w-4 h-4 ${burned ? "text-danger" : "text-primary"}`} />
        <span className="font-mono text-sm text-foreground">{domain}</span>
        {burned && <span className="badge-glow-red text-[10px] px-2 py-0.5 rounded-full font-mono">QUARANTINED</span>}
      </div>
      <div className="flex gap-2">
        <Badge ok={spf} label="SPF" />
        <Badge ok={dkim} label="DKIM" />
        <Badge ok={dmarc} label="DMARC" warning={!dmarcStrict && dmarc} />
      </div>
    </div>
  );
}

function Badge({ ok, label, warning }: { ok: boolean; label: string; warning?: boolean }) {
  const cls = !ok ? "badge-glow-red" : warning ? "badge-glow-amber" : "badge-glow-green";
  const Icon = !ok ? XCircle : warning ? AlertTriangle : CheckCircle2;
  return (
    <span className={`${cls} text-[10px] px-2 py-1 rounded-md font-mono flex items-center gap-1`}>
      <Icon className="w-3 h-3" /> {label}
    </span>
  );
}

function TerminalLog({ logs }: { logs: LogEntry[] }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [logs]);

  const typeColor = (t: string) => {
    switch (t) {
      case "alert": return "text-danger";
      case "action": return "text-primary";
      case "success": return "text-accent";
      default: return "text-muted-foreground";
    }
  };
  const typeLabel = (t: string) => {
    switch (t) {
      case "alert": return "[Alert]";
      case "action": return "[Action]";
      case "success": return "[OK]";
      default: return "[Info]";
    }
  };

  return (
    <div ref={ref} className="terminal-bg rounded-xl border border-border p-4 h-64 overflow-y-auto font-mono text-xs space-y-1">
      {logs.map((l) => (
        <div key={l.id} className="animate-slide-up flex gap-2">
          <span className="text-muted-foreground/60 shrink-0">{l.time}</span>
          <span className={`${typeColor(l.type)} shrink-0`}>{typeLabel(l.type)}</span>
          <span className="text-foreground/80">{l.message}</span>
        </div>
      ))}
      <div className="flex items-center gap-1 text-primary animate-pulse-glow mt-1">
        <span>▊</span>
      </div>
    </div>
  );
}

// ─── Main Component ────────────────────────────────────────────────
export default function RepuShieldApp() {
  const [score, setScore] = useState(98);
  const [prediction, setPrediction] = useState("Blacklist Risk: Low — Safe to scale volume");
  const [predictionLevel, setPredictionLevel] = useState<"low" | "medium" | "high">("low");

  const [dkimFailed, setDkimFailed] = useState(false);
  const [acmeBurned, setAcmeBurned] = useState(false);

  const [chartData, setChartData] = useState<ChartPoint[]>(generateInitialChart);
  const [sendInterval, setSendInterval] = useState(2000);

  const [queue, setQueue] = useState<QueueItem[]>(() =>
    MOCK_SUBSCRIBERS
      .sort((a, b) => b.engagement - a.engagement)
      .map((s, i) => ({ ...s, id: i, status: "Pending" as const, sentFrom: "@acme.com" }))
  );

  const [logs, setLogs] = useState<LogEntry[]>([
    { id: 0, time: now(), type: "info", message: "RepuShield v2.1 initialized. Connected to MailerLite API." },
    { id: 1, time: now(), type: "info", message: "Loading domain health data..." },
    { id: 2, time: now(), type: "success", message: "All systems nominal. Engagement-based queue loaded." },
  ]);

  const [spamEmailContent, setSpamEmailContent] = useState(SPAMMY_EMAIL);
  const [spamScore, setSpamScore] = useState(85);
  const [rewriting, setRewriting] = useState(false);
  const [showSpamModal, setShowSpamModal] = useState(false);

  const logId = useRef(3);
  const addLog = useCallback((type: LogEntry["type"], message: string) => {
    setLogs((prev) => [...prev, { id: logId.current++, time: now(), type, message }]);
  }, []);

  // ─── Auto-send emails ───────────────────────────────────────────
  useEffect(() => {
    const interval = setInterval(() => {
      setQueue((prev) => {
        const idx = prev.findIndex((q) => q.status === "Pending");
        if (idx === -1) return prev;
        const updated = [...prev];
        const item = { ...updated[idx] };

        // 1 in 10 spam trap
        if (Math.random() < 0.1) {
          item.status = "Spam Trap";
          addLog("alert", `Detects Spam Trap Risk for ${item.email} — skipping.`);
        } else {
          item.status = "Sent";
        }
        updated[idx] = item;
        return updated;
      });
    }, sendInterval);
    return () => clearInterval(interval);
  }, [sendInterval, addLog]);

  // ─── Slowly recover score ──────────────────────────────────────
  useEffect(() => {
    const interval = setInterval(() => {
      setScore((s) => {
        if (s < 98) return Math.min(98, s + 1);
        return s;
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Update prediction based on score
  useEffect(() => {
    if (score > 80) {
      setPrediction("Blacklist Risk: Low — Safe to scale volume");
      setPredictionLevel("low");
    } else if (score > 50) {
      setPrediction("Blacklist Risk: ELEVATED — Throttling recommended");
      setPredictionLevel("medium");
    } else {
      setPrediction("Blacklist Risk: IMMINENT — Emergency protocols active");
      setPredictionLevel("high");
    }
  }, [score]);

  // ─── Simulate Spam Spike ────────────────────────────────────────
  const simulateSpamSpike = () => {
    setScore(75);
    setSendInterval(5000);
    // spike chart
    setChartData((prev) => prev.map((p, i) => i > 18 ? { ...p, spam: p.spam + 1.5 + Math.random() } : p));
    // throttle pending emails
    setQueue((prev) => prev.map((q) => q.status === "Pending" ? { ...q, status: "Throttled" as const } : q));

    setTimeout(() => addLog("alert", "Spam complaint tracking exceeded 0.2% threshold."), 200);
    setTimeout(() => addLog("action", "Automatically adjusting sending volume."), 800);
    setTimeout(() => addLog("action", "Smart email throttling engaged. Rate: 1 email / 5s."), 1500);
    setTimeout(() => addLog("action", "Initiating Automated Email warmup algorithm."), 2200);
    setTimeout(() => {
      addLog("success", "Warmup cycle started. Gradual volume recovery in progress.");
      // unthrottle after a delay
      setQueue((prev) => prev.map((q) => q.status === "Throttled" ? { ...q, status: "Pending" as const } : q));
    }, 3500);
  };

  // ─── Simulate DKIM Failure ──────────────────────────────────────
  const simulateDkimFailure = () => {
    setScore(42);
    setDkimFailed(true);
    setAcmeBurned(true);

    setTimeout(() => addLog("alert", "DKIM signature validation FAILED for @acme.com."), 200);
    setTimeout(() => addLog("alert", "Blacklist auto-detection triggered."), 800);
    setTimeout(() => addLog("action", "Quarantining burned domain (@acme.com)."), 1400);
    setTimeout(() => addLog("action", "Executing Self-healing domain rotation..."), 2000);
    setTimeout(() => {
      addLog("action", "Rerouting all traffic to @acme.co.");
      setQueue((prev) => prev.map((q) => q.status === "Pending" ? { ...q, sentFrom: "@acme.co" } : q));
    }, 2600);
    setTimeout(() => addLog("success", "Domain rotation complete. @acme.co is now primary."), 3400);
  };

  // ─── Reset ──────────────────────────────────────────────────────
  const resetAll = () => {
    setScore(98);
    setDkimFailed(false);
    setAcmeBurned(false);
    setSendInterval(2000);
    setChartData(generateInitialChart());
    setQueue(
      MOCK_SUBSCRIBERS
        .sort((a, b) => b.engagement - a.engagement)
        .map((s, i) => ({ ...s, id: i, status: "Pending" as const, sentFrom: "@acme.com" }))
    );
    setSpamEmailContent(SPAMMY_EMAIL);
    setSpamScore(85);
    addLog("info", "System reset. All parameters restored to baseline.");
  };

  // ─── AI Rewrite ─────────────────────────────────────────────────
  const rewriteWithAI = () => {
    setRewriting(true);
    setTimeout(() => {
      setSpamEmailContent(CLEAN_EMAIL);
      setSpamScore(2);
      setRewriting(false);
      addLog("success", "SambaNova AI rewrote email content. Spam score dropped to 2%.");
    }, 2500);
  };

  const predColor = predictionLevel === "low" ? "text-accent" : predictionLevel === "medium" ? "text-warning" : "text-danger";

  return (
    <div className="min-h-screen bg-background p-4 md:p-6 space-y-6">
      {/* Header */}
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center glow-cyan">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">RepuShield</h1>
            <p className="text-xs text-muted-foreground">AI Email Reputation Protection • MailerLite Integration</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="badge-glow-green text-[10px] px-2 py-1 rounded-full font-mono flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-accent rounded-full animate-pulse" /> LIVE
          </span>
        </div>
      </header>

      {/* ═══ SECTION 1: Global Health ═══ */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Score Gauge */}
        <div className="lg:col-span-3 gradient-card rounded-xl p-6 flex flex-col items-center justify-center">
          <ScoreGauge score={score} />
          <div className={`mt-4 text-center ${predColor} text-xs font-mono font-semibold`}>
            <Activity className="w-3 h-3 inline mr-1" />
            {prediction}
          </div>
        </div>

        {/* Domain Health Cards */}
        <div className="lg:col-span-5 space-y-3">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
            <Server className="w-3 h-3" /> Domain & IP Health
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <DomainCard domain="@acme.com" spf dkim={!dkimFailed} dmarc dmarcStrict burned={acmeBurned} />
            <DomainCard domain="@acme.co" spf dkim dmarc dmarcStrict={false} />
            <DomainCard domain="@acme.io" spf dkim dmarc dmarcStrict />
          </div>
        </div>

        {/* Infra Suggestion */}
        <div className="lg:col-span-4 space-y-3">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
            <Info className="w-3 h-3" /> Infrastructure Suggestions
          </h2>
          <div className="gradient-card rounded-xl p-4 space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-lg bg-warning/5 border border-warning/20">
              <AlertTriangle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-foreground/90">
                  <span className="font-semibold text-warning">@acme.co</span> is missing DMARC strict policy.
                </p>
                <button className="text-[10px] text-primary hover:underline mt-1 flex items-center gap-1">
                  Auto-generate DNS record <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-lg bg-primary/5 border border-primary/20">
              <Zap className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-foreground/90">
                  Consider adding a dedicated IP for cold outreach to isolate reputation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ SECTION 2: Live Action Simulator ═══ */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Chart */}
        <div className="lg:col-span-7 gradient-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
              <TrendingUp className="w-3 h-3" /> Real-Time Bounce & Spam Monitoring (24h)
            </h2>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="bounceGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(173,80%,50%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(173,80%,50%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="spamGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(0,72%,51%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(0,72%,51%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(222,30%,16%)" />
              <XAxis dataKey="time" tick={{ fontSize: 10, fill: "hsl(215,20%,55%)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "hsl(215,20%,55%)" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: "hsl(222,47%,9%)", border: "1px solid hsl(222,30%,16%)", borderRadius: 8, fontSize: 11 }}
                labelStyle={{ color: "hsl(210,40%,96%)" }}
              />
              <Area type="monotone" dataKey="bounces" stroke="hsl(173,80%,50%)" fill="url(#bounceGrad)" strokeWidth={2} name="Bounce %" />
              <Area type="monotone" dataKey="spam" stroke="hsl(0,72%,51%)" fill="url(#spamGrad)" strokeWidth={2} name="Spam %" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Spam Scorer */}
        <div className="lg:col-span-5 gradient-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
              <Mail className="w-3 h-3" /> AI Content Spam Scoring
            </h2>
            <button onClick={() => setShowSpamModal(!showSpamModal)} className="text-[10px] badge-glow-cyan px-2 py-1 rounded-md font-mono">
              {showSpamModal ? "Hide" : "Preview Draft"}
            </button>
          </div>

          <AnimatePresence>
            {showSpamModal && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>
                <div className="space-y-3">
                  <div className="terminal-bg rounded-lg p-3 border border-border">
                    <p className="text-[10px] text-muted-foreground mb-1">Subject:</p>
                    <p className="text-xs text-foreground font-mono">{spamEmailContent.subject}</p>
                    <p className="text-[10px] text-muted-foreground mt-2 mb-1">Body:</p>
                    <p className="text-xs text-foreground/80">{spamEmailContent.body}</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">Auto Spam Score:</span>
                      <span className={`font-mono text-sm font-bold ${spamScore > 50 ? "text-danger" : "text-accent"}`}>
                        {spamScore}%{spamScore > 50 ? " Risk" : " Clean"}
                      </span>
                    </div>
                    <button
                      onClick={rewriteWithAI}
                      disabled={rewriting || spamScore < 10}
                      className="flex items-center gap-1 text-xs bg-primary/10 text-primary px-3 py-1.5 rounded-lg hover:bg-primary/20 transition disabled:opacity-40 font-mono"
                    >
                      {rewriting ? (
                        <><RotateCcw className="w-3 h-3 animate-spin" /> Rewriting...</>
                      ) : (
                        <><Sparkles className="w-3 h-3" /> Rewrite with SambaNova AI</>
                      )}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {!showSpamModal && (
            <div className="flex flex-col items-center justify-center h-32">
              <div className={`text-5xl font-mono font-bold ${spamScore > 50 ? "text-danger" : "text-accent"}`}>{spamScore}%</div>
              <p className="text-xs text-muted-foreground mt-2">{spamScore > 50 ? "High Risk — Review Draft" : "Clean — Ready to Send"}</p>
            </div>
          )}
        </div>
      </section>

      {/* Smart Queue */}
      <section className="gradient-card rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
            <Send className="w-3 h-3" /> Smart Queue — Engagement-Based Sending
            <span className="badge-glow-cyan text-[10px] px-2 py-0.5 rounded-full">
              {sendInterval === 2000 ? "2s/email" : "5s/email (throttled)"}
            </span>
          </h2>
          <span className="text-[10px] text-muted-foreground font-mono">
            Sent: {queue.filter((q) => q.status === "Sent").length} / {queue.length}
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-muted-foreground border-b border-border">
                <th className="text-left py-2 px-3 font-medium">Subscriber</th>
                <th className="text-left py-2 px-3 font-medium">Segment</th>
                <th className="text-left py-2 px-3 font-medium">Engagement</th>
                <th className="text-left py-2 px-3 font-medium">Status</th>
                <th className="text-left py-2 px-3 font-medium">Sent From</th>
              </tr>
            </thead>
            <tbody>
              {queue.map((q) => (
                <tr key={q.id} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                  <td className="py-2 px-3">
                    <div>
                      <span className="text-foreground">{q.name}</span>
                      <span className="text-muted-foreground ml-2">{q.email}</span>
                    </div>
                  </td>
                  <td className="py-2 px-3">
                    <span className={q.segment === "Friendlies" ? "badge-glow-green" : "badge-glow-amber"} style={{ padding: "2px 8px", borderRadius: 6, fontSize: 10 }}>
                      {q.segment}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-mono">{q.engagement}%</td>
                  <td className="py-2 px-3">
                    <StatusBadge status={q.status} />
                  </td>
                  <td className="py-2 px-3 font-mono text-muted-foreground">{q.sentFrom}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* ═══ SECTION 3: God-Mode Control Panel ═══ */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-4 space-y-3">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
            <Zap className="w-3 h-3" /> God-Mode Control Panel
          </h2>
          <div className="space-y-2">
            <button
              onClick={simulateSpamSpike}
              className="w-full flex items-center gap-3 p-3 rounded-xl bg-danger/10 border border-danger/20 hover:bg-danger/20 transition text-left group"
            >
              <TrendingDown className="w-5 h-5 text-danger" />
              <div>
                <p className="text-xs font-semibold text-foreground">Simulate Spam Spike</p>
                <p className="text-[10px] text-muted-foreground">Triggers throttling & warmup</p>
              </div>
            </button>
            <button
              onClick={simulateDkimFailure}
              className="w-full flex items-center gap-3 p-3 rounded-xl bg-danger/10 border border-danger/20 hover:bg-danger/20 transition text-left group"
            >
              <XCircle className="w-5 h-5 text-danger" />
              <div>
                <p className="text-xs font-semibold text-foreground">Simulate DKIM Failure</p>
                <p className="text-[10px] text-muted-foreground">Triggers domain rotation</p>
              </div>
            </button>
            <button
              onClick={resetAll}
              className="w-full flex items-center gap-3 p-3 rounded-xl bg-primary/10 border border-primary/20 hover:bg-primary/20 transition text-left"
            >
              <RotateCcw className="w-5 h-5 text-primary" />
              <div>
                <p className="text-xs font-semibold text-foreground">Reset All Systems</p>
                <p className="text-[10px] text-muted-foreground">Restore to baseline</p>
              </div>
            </button>
          </div>
        </div>
        <div className="lg:col-span-8 space-y-3">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
            <Terminal className="w-3 h-3" /> Auto-Healing Console
          </h2>
          <TerminalLog logs={logs} />
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center text-[10px] text-muted-foreground/40 py-4 font-mono">
        RepuShield v2.1 • AI-Powered Email Reputation Protection • Built on MailerLite API + SambaNova AI
      </footer>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case "Sent":
      return <span className="badge-glow-green text-[10px] px-2 py-0.5 rounded-md font-mono flex items-center gap-1 w-fit"><CheckCircle2 className="w-3 h-3" /> Sent</span>;
    case "Throttled":
      return <span className="badge-glow-amber text-[10px] px-2 py-0.5 rounded-md font-mono flex items-center gap-1 w-fit animate-pulse-glow"><Clock className="w-3 h-3" /> Throttled</span>;
    case "Spam Trap":
      return <span className="badge-glow-red text-[10px] px-2 py-0.5 rounded-md font-mono flex items-center gap-1 w-fit"><AlertTriangle className="w-3 h-3" /> Spam Trap</span>;
    default:
      return <span className="badge-glow-cyan text-[10px] px-2 py-0.5 rounded-md font-mono flex items-center gap-1 w-fit"><SkipForward className="w-3 h-3" /> Pending</span>;
  }
}
